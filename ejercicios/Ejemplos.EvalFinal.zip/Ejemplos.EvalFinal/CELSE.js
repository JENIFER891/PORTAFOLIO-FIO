let hora = 15;

if (hora < 12) {
  console.log("Buenos días");
} else {
  console.log("Buenas tardes");
}
