let edad = 18;

if (edad >= 18) {
  console.log("Eres mayor de edad");
}
