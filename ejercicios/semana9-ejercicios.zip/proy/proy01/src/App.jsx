import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  //Codigo JSX
  const [count, setCount] = useState(0)

  return (
    <>
      <h1>Soy el componente App </h1>
      {/*Codigo html y css */}

    </>
  )
}

export default App
