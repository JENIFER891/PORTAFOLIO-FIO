import react from 'react'
import '../assets/estilo01.css'
const nombre="fio"
const myId="miElemento"
const estilo = {color: "blue", fontSize:"20px"}
function saludar(nombre){
    return `Hola ${nombre}!!!`
}
const componente01 =() => {
    return (
        <>
        <div className='clase01' style={estilo}>
            <h1>{saludar(nombre)}</h1>
            <p>{nombre&&"Bienvenido nuevamemte"}</p>
            <ul>
                ["UNCP", "FIS", "2025"].map((txt) => (
                    <li key={txt}>{txt}</li>
                ))
            </ul>
            <p></p>
        </div>

        </>
    )

}

export default componente01